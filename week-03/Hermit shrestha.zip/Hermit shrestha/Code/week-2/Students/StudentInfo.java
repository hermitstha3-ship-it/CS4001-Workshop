public class StudentInfo{
    public static void main(String[] args){
        String name="Ram Tharu";
        int Age=19;
        double GPA=3.26;
        
        System.out.println("=======Student Information======");
        System.out.println("Name: "+name);
        System.out.println("Age: "+Age);
        System.out.println("GPA: "+GPA);
    }

}