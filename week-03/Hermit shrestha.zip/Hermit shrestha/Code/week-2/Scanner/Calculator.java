import java.util.Scanner; 

public class Calculator
{
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        
        System.out.println("Enter the first number");
        int firstNum=sc.nextInt();
        
        System.out.println("Enter the Second number");
        int secNum=sc.nextInt();
        
        System.out.println("First number is: "+firstNum);
        System.out.println("Second number is: "+secNum);
    }
}