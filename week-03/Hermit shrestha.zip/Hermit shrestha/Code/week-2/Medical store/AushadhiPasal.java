public class AushadhiPasal {
 public static void main(String[] args) {
     var Medicine1 = "Paracetamol";
     var Medicine2 = "Amoxicillin";
     var Medicine3 = "Omeprazole";
     System.out.println("=============================================");
     System.out.println("              Medicine Information");
     System.out.println("=============================================");
     System.out.println("Medicine1:Paracetamol");
     System.out.println("English Name : Paracetamol(or Acetaminophen)");
     System.out.println("Nepali Name : पारसिटामोल");
     System.out.println("Price : NPR 1.00 per tablet");
     System.out.println("Stock Quantity : 125 tablets");
     System.out.println("");
     System.out.println("Medicine2:Amoxicillin");
     System.out.println("English Name : Amoxicillin");
     System.out.println("Nepali Name : एमोक्सिसिलिन");
     System.out.println("Price : NPR 8.00 per tablet");
     System.out.println("Stock Quantity : 200 Tablets");
     System.out.println("");
     System.out.println("Medicine3:Omeprazole");
     System.out.println("English Name : Omeprazole");
     System.out.println("Nepali Name : ओमेप्राजोल ");
     System.out.println("Price : NPR 4.00 per tablet");
     System.out.println("Stock Quantity : 136 Tablets");
     System.out.println("==============================================");
     System.out.println("Inventory Report");
     System.out.println("Paracetamol (पारसिटामोल) | NPR 1.00 per table | 125 tablets |Prescription Required");
     System.out.println("Amoxicillin (एमोक्सिसिलिन) | NPR 8.00 per tablet | 200 Tablets |Prescription Required");
     System.out.println("MOmeprazole (ओमेप्राजोल) | NPR 4.00 per tablet | 136 Tablets |Prescription Required");
     System.out.println("");
     System.out.println("               AUSHADI PASAL");
    }
}
