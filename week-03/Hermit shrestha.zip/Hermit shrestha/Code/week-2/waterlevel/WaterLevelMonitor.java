//Water Level Monitor
import java.util.Scanner;

public class WaterLevelMonitor
{
    public static void main(String[] args){
    Scanner sc= new Scanner(System.in);
    int Liters1 = 950;
    int Liters2 = 1000;
    int Liters3 = 1200;
    System.out.println("Enter the current water level(950,1000,1200)");
    int level = sc.nextInt();
    var Liters = (level >= 1000)? "Water level has reached 1000L or more" : "Normal";
    System.out.println(Liters);
    }
}