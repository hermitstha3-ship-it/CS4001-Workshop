import java.util.Scanner;
public class GradeEvaluator
{
    public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    
    System.out.println("Enter the grade");
    int marks =sc.nextInt();//take inout from user
    
    String grade = (marks>=40)?"pass":"fail";//Ternery operator conditional check
    System.out.println("The Student have "+grade+" the exam");//Output
    }
}