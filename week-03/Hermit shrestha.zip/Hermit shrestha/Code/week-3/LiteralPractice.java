public class LiteralPractice
{
    public static void main(String[] args){
        long largenumber = 9204067910237751l;
        float Value = 3.14159f;
        char CopyRight = '\u00A9';
        System.out.println("Long Data type value:"+largenumber);//LARGE VALUE
        System.out.println("Float Data type value"+Value);//FLOAT VALUE
        System.out.println("Char data type unicode \\u00A9):"+CopyRight);//UNICODE CHARACTER 
    }
}