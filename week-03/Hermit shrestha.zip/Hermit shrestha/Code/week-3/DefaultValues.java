public class DefaultValues
{
    byte by;
    short s;
    int i;
    long l;
    float f;
    double d;
    boolean b;
    char c;
    
    public static void main(String[] args){
        
        DefaultValues obj = new DefaultValues();
        System.out.println("--- Default Values of Uninitialized Member Variables ---");
        System.out.println("byteValue: " + obj.by);
        System.out.println("shortValue: " + obj.s);
        System.out.println("intValue: " +  obj.i);
        System.out.println("longValue: " + obj.l);
        System.out.println("floatValue: " + obj.f);
        System.out.println("doubleValue: " + obj.d);
        System.out.println("booleanValue: " + obj.b);
        System.out.println("charValue: " +obj.c);
        /*COMMENTARY: Why this won't work for local variable:
         * If those varible are declared inside the main method (a local variable) and
         * not initialized, the Java compiler would produce a 'compile time error'
         * The JVM provides default values (Likes 0,0.0,false) only for instance 
         * variable and static variables. Local variables are stored on the method
         * stack are not automatically initialized by the JVM. The compiler forces 
         * the programmer assign a value to a local variable before using it to
         * prevent the program from relying on unknown or garbage values from the stack
         * memory.
        */
         
    }
}