import java.util.Scanner;
public class RickshawFare{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        final double BASE_FARE = 25.0;
        final double RATE_PER_KM = 15.0;
        final double RATE_PER_MINUTE = 2.0;
        final double LOCAL_DISCOUNT_PERCENT = 0.10;
        final double NIGHT_CHARGE_PERCENT = 0.25;
        final double DISCOUNT_THRESHOLD_KM = 5.0;
        
        System.out.println("=================================================");
        System.out.println("          🛺 Rickshaw Fare Calculator 🛺          ");
        System.out.println("=================================================");
        
        System.out.println("Enter total distance traveled (km): ");
        double distanceKm = sc.nextDouble();//Input total distance travelled
        
        System.out.println("Enter total time spent (minutes): ");
        double timeMinutes = sc.nextDouble();//Input
        
        System.out.println("Is this a local trip? (true/false): ");
        boolean isLocal = sc.nextBoolean();
        
        System.out.println("Is this a night trip? (true/false): ");
        boolean isNight = sc.nextBoolean();

        double distanceCharge = distanceKm * RATE_PER_KM;
        double timeCharge = timeMinutes * RATE_PER_MINUTE;
        
        double baseCalculatedFare = BASE_FARE + distanceCharge + timeCharge;//Total fare
        
        boolean applyDiscount = isLocal && (distanceKm >= DISCOUNT_THRESHOLD_KM);//check discount
        double discountAmount = baseCalculatedFare * LOCAL_DISCOUNT_PERCENT;
        
        double fareAfterDiscount = baseCalculatedFare - (applyDiscount ? discountAmount : 0.0);// Apply discount only if applyDiscount is true
        
        double nightSurcharge = fareAfterDiscount * NIGHT_CHARGE_PERCENT;
        double finalFare = fareAfterDiscount + (isNight ? nightSurcharge : 0.0);// Apply night surcharge only if isNight is true
        System.out.println("\n-------------------------------------------------");
        System.out.println("Trip Summary:");
        
        System.out.println("  Distance: "+distanceKm+" Time: "+timeMinutes+" min\sec");
        System.out.println("  Discount Applied:"+(applyDiscount ? "Yes" : "No")+" Night Surcharge Applied:"+(isNight ? "Yes" : "No"));
        System.out.println("-------------------------------------------------");
        System.out.println("TOTAL FINAL FARE: Rs."+ finalFare);//Total fare value
        System.out.println("=================================================");
    }
}