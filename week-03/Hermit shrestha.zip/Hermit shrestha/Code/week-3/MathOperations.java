public class MathOperations{
    public static void main(String[] args){
        int a = 50;//assignment operator
        int b = 20;//assignment operator
        int e,f,g;//assignment operator
        a += 5;//assignment operator
        b -=10;//assignment operator
        int sum = a+b;//Arithemetic operator
        int c = a++;//Special arithmetic operator
        int d = b--;//Speacial arithmetic operator
        e = c;//assignment operator
        f = d;//assignment operator
        g = sum;//assignment operator
        e *= 1;//assignment operator
        f /= 10;//assignment operator
        g %= 10;//assignment operator
        boolean greater = (a>b);//relation operator
        boolean smaller = (b<a);//relation operator
        boolean equal = (a==b);//relation operator
        boolean not_equal = (a!=b);//relaton operator
        boolean greater_then_or_equal = (a>=b);//relation operator
        boolean less_then_or_equal = (a<=b);//realation operator
        boolean n = (a>50 && a>b);//logical operator
        boolean m = (b<a || b<20);//logical operator
        String grade = (sum>=100)? "Pass":"Fail";//Ternary operator
        int and = 5 & 3;//binary operator
        int or = 5|3;//binary operator
        int xor = 5^3;//binary operator
        int not = ~5;//binary operator
        int left_shift = 5<<1;//binary operator
        int right_shift = 5>>1;//binary operator
        
        System.out.println("The Sum of a and b is:"+sum);//Arithmetic operator
        System.out.println("The Difference of a and b is:"+(a-b));//Arithmetic operator
        System.out.println("The Multiplication of a and b is:"+(a*b));//Arithmetic operator
        System.out.println("The Division of a and b is:"+(a/b));//Arithmetic operator
        System.out.println("The Remainder of a and b is:"+(a%b));//Arithmetic operator
        System.out.println("The Student has:"+grade);//Ternary operator
        System.out.println("The increment of a is:"+c);//Arithmetic operator
        System.out.println("The decrement of b is:"+d);//Arithmetic operator
        System.out.println("The a greater than b:"+greater);//relation operator
        System.out.println("Is b smaller then a:"+smaller);//relation operator
        System.out.println("Is a and b equal?:"+equal);//relation operator
        System.out.println("a and b not equal?"+not_equal);//relation operator
        System.out.println("Is a greater than or equal to b"+greater_then_or_equal);//relation operator
        System.out.println("Is a less than or equal to b"+less_then_or_equal);//relation operator
        System.out.println("Binary operator and ="+and);//Binary operator
        System.out.println("Binary operator or ="+or);//Binary operator
        System.out.println("Binary operator not ="+not);//Binary operator
        System.out.println("Binary operator left shift ="+left_shift);//Binary operator
        System.out.println("Binary operator right shift ="+right_shift);//Binary operator
        System.out.println("a greater"+n);//logical operator
        System.out.println("b smaller:"+m);//logical operator
        System.out.println("e="+e);//assignment operator
        System.out.println("f="+f);//assignment operator
        System.out.println("g="+g);//assignment operator
        
    }
}