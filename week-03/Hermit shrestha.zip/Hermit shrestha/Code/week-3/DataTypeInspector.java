public class DataTypeInspector
{
    
    public static void main(String[] args){
    byte a = 100;
    short b = 2000;
    int c = 55000;
    long d = 1000000l;
    float e = 10.9f;
    double f = 100.999d;
    boolean IsEligible = true;
    char name = 'A';
    System.out.println("This is byte datatype:"+a);//byte data type
    System.out.println("This is short datatype:"+b);//short data type
    System.out.println("This is int datatype:"+c);//interger data type
    System.out.println("This is long datatype:"+d);//long data type
    System.out.println("This is float datatype:"+e);//float datatype
    System.out.println("This is double datatype:"+f);//double data type
    System.out.println("This is boolean datatype:"+IsEligible);//boolean data type
    System.out.println("This is char datatype:"+name);//character data type
    }
}